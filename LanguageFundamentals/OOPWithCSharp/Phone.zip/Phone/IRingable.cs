﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Phone
{
    public interface IRingable
    {
        string Ring();
        // public string Unlock() {}
    }
}
