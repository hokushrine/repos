namespace WeddingPlanner.Models
{
    public class LogRegModel
    {
        public User Register {get;set;}
        public LoginUser Login {get;set;}
    }
}