namespace DojoSurveyWithModel.Models
{
    public class Survey
    {
        public string Name {get; set;}
        public string Favorite {get; set;}
        public string Location {get; set;}
        public string Comment {get; set;}
    }
}