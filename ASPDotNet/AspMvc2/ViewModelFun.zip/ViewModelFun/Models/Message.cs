namespace ViewModelFun.Models
{
    public class Message
    {
        public string Msg {get;set;}
    }
}