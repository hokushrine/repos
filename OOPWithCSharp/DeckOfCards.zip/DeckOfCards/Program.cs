﻿using System;

namespace DeckOfCards
{
    class Program
    {
        static void Main(string[] args)
        {
            var card = new Card("4", 12);
            
            card.SayCard();
        }
    }
}
